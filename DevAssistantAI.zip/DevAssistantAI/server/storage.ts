import { 
  Molecule, InsertMolecule,
  Reaction, InsertReaction,
  Explanation, InsertExplanation,
  FunctionalGroup, InsertFunctionalGroup,
  ReactionType
} from "@shared/schema";

export interface IStorage {
  // Functional Groups
  getFunctionalGroup(id: number): Promise<FunctionalGroup | undefined>;
  getFunctionalGroups(): Promise<FunctionalGroup[]>;
  createFunctionalGroup(group: InsertFunctionalGroup): Promise<FunctionalGroup>;

  // Molecules
  getMolecule(id: number): Promise<Molecule | undefined>;
  getMolecules(): Promise<Molecule[]>;
  createMolecule(molecule: InsertMolecule): Promise<Molecule>;

  // Reactions
  getReaction(id: number): Promise<Reaction | undefined>;
  getReactions(): Promise<Reaction[]>;
  createReaction(reaction: InsertReaction): Promise<Reaction>;

  // Explanations
  getExplanation(id: number): Promise<Explanation | undefined>;
  getExplanationsForReaction(reactionId: number): Promise<Explanation[]>;
  createExplanation(explanation: InsertExplanation): Promise<Explanation>;
}

// Initial data for testing
const INITIAL_FUNCTIONAL_GROUPS = [
  {
    id: 1,
    name: "Alcohol",
    description: "Organic compounds containing one or more hydroxyl (-OH) groups",
    structure: { atoms: [], bonds: [] }
  },
  {
    id: 2,
    name: "Alkene",
    description: "Hydrocarbons containing at least one carbon-carbon double bond",
    structure: { atoms: [], bonds: [] }
  },
  {
    id: 3,
    name: "Alkyne",
    description: "Hydrocarbons containing at least one carbon-carbon triple bond",
    structure: { atoms: [], bonds: [] }
  }
];

const INITIAL_REACTIONS = [
  {
    id: 1,
    name: "Dehydration of Alcohol",
    functionalGroupId: 1,
    type: ReactionType.REACTION,
    description: "The removal of water from an alcohol molecule to form an alkene, usually requiring heat and an acid catalyst.",
    equation: "CH3CH2OH → CH2=CH2 + H2O",
    mechanism: {
      steps: [
        { description: "Protonation of alcohol", arrows: [] },
        { description: "Loss of water", arrows: [] },
        { description: "Formation of alkene", arrows: [] }
      ]
    },
    conditions: {
      temperature: "180°C",
      catalyst: "H2SO4",
      pressure: "atmospheric"
    },
    reactants: [
      { id: 1, name: "Ethanol", quantity: "1 mol" }
    ],
    products: [
      { id: 2, name: "Ethene", quantity: "1 mol" },
      { id: 3, name: "Water", quantity: "1 mol" }
    ],
    difficulty: 2,
    videoUrl: null
  },
  {
    id: 2,
    name: "Hydrogenation of Alkene",
    functionalGroupId: 2,
    type: ReactionType.REACTION,
    description: "Addition of molecular hydrogen across a carbon-carbon double bond to form an alkane using a metal catalyst.",
    equation: "RCH=CH2 + H2 → RCH2-CH3",
    mechanism: {
      steps: [
        { description: "Adsorption of alkene on catalyst surface", arrows: [] },
        { description: "Dissociation of H2 on catalyst surface", arrows: [] },
        { description: "Addition of hydrogen atoms", arrows: [] }
      ]
    },
    conditions: {
      temperature: "25°C",
      catalyst: "Pt/Pd",
      pressure: "1-3 atm"
    },
    reactants: [
      { id: 4, name: "Alkene", quantity: "1 mol" },
      { id: 5, name: "Hydrogen", quantity: "1 mol" }
    ],
    products: [
      { id: 6, name: "Alkane", quantity: "1 mol" }
    ],
    difficulty: 1,
    videoUrl: null
  },
  {
    id: 3,
    name: "Halogenation of Alkene",
    functionalGroupId: 2,
    type: ReactionType.REACTION,
    description: "Addition of halogen (X2) across a carbon-carbon double bond to form a dihalide through a cyclic halonium ion intermediate.",
    equation: "RCH=CH2 + X2 → RCHx-CH2X",
    mechanism: {
      steps: [
        { description: "Formation of halonium ion", arrows: [] },
        { description: "Nucleophilic attack by halide ion", arrows: [] },
        { description: "Formation of dihalide product", arrows: [] }
      ]
    },
    conditions: {
      temperature: "25°C",
      solvent: "CCl4",
      catalyst: "none"
    },
    reactants: [
      { id: 7, name: "Alkene", quantity: "1 mol" },
      { id: 8, name: "Halogen", quantity: "1 mol" }
    ],
    products: [
      { id: 9, name: "Dihalide", quantity: "1 mol" }
    ],
    difficulty: 3,
    videoUrl: null
  }
];

export class MemStorage implements IStorage {
  private functionalGroups: Map<number, FunctionalGroup>;
  private molecules: Map<number, Molecule>;
  private reactions: Map<number, Reaction>;
  private explanations: Map<number, Explanation>;
  private currentIds: { [key: string]: number };

  constructor() {
    this.functionalGroups = new Map();
    this.molecules = new Map();
    this.reactions = new Map();
    this.explanations = new Map();
    this.currentIds = { 
      functionalGroups: INITIAL_FUNCTIONAL_GROUPS.length + 1,
      molecules: 1, 
      reactions: INITIAL_REACTIONS.length + 1, 
      explanations: 1 
    };

    // Initialize with sample data
    INITIAL_FUNCTIONAL_GROUPS.forEach(group => {
      this.functionalGroups.set(group.id, group as FunctionalGroup);
    });

    INITIAL_REACTIONS.forEach(reaction => {
      this.reactions.set(reaction.id, reaction as Reaction);
    });
  }

  // Functional Groups
  async getFunctionalGroup(id: number): Promise<FunctionalGroup | undefined> {
    return this.functionalGroups.get(id);
  }

  async getFunctionalGroups(): Promise<FunctionalGroup[]> {
    return Array.from(this.functionalGroups.values());
  }

  async createFunctionalGroup(group: InsertFunctionalGroup): Promise<FunctionalGroup> {
    const id = this.currentIds.functionalGroups++;
    const newGroup: FunctionalGroup = {
      id,
      name: group.name,
      description: group.description ?? null,
      structure: group.structure ?? null
    };
    this.functionalGroups.set(id, newGroup);
    return newGroup;
  }

  // Molecules
  async getMolecule(id: number): Promise<Molecule | undefined> {
    return this.molecules.get(id);
  }

  async getMolecules(): Promise<Molecule[]> {
    return Array.from(this.molecules.values());
  }

  async createMolecule(molecule: InsertMolecule): Promise<Molecule> {
    const id = this.currentIds.molecules++;
    const newMolecule: Molecule = {
      ...molecule,
      id,
      molecularWeight: molecule.molecularWeight ?? null
    };
    this.molecules.set(id, newMolecule);
    return newMolecule;
  }

  // Reactions
  async getReaction(id: number): Promise<Reaction | undefined> {
    return this.reactions.get(id);
  }

  async getReactions(): Promise<Reaction[]> {
    return Array.from(this.reactions.values());
  }

  async createReaction(reaction: InsertReaction): Promise<Reaction> {
    const id = this.currentIds.reactions++;
    const newReaction: Reaction = {
      ...reaction,
      id,
      mechanism: reaction.mechanism ?? null,
      videoUrl: reaction.videoUrl ?? null
    };
    this.reactions.set(id, newReaction);
    return newReaction;
  }

  // Explanations
  async getExplanation(id: number): Promise<Explanation | undefined> {
    return this.explanations.get(id);
  }

  async getExplanationsForReaction(reactionId: number): Promise<Explanation[]> {
    return Array.from(this.explanations.values())
      .filter(exp => exp.reactionId === reactionId);
  }

  async createExplanation(explanation: InsertExplanation): Promise<Explanation> {
    const id = this.currentIds.explanations++;
    const newExplanation: Explanation = {
      ...explanation,
      id,
      aiGenerated: explanation.aiGenerated ?? false
    };
    this.explanations.set(id, newExplanation);
    return newExplanation;
  }
}

export const storage = new MemStorage();