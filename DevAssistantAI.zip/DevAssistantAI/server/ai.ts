import { GoogleGenerativeAI } from "@google/generative-ai";
import { Reaction } from "@shared/schema";

if (!process.env.GEMINI_API_KEY) {
  throw new Error("GEMINI_API_KEY environment variable is required");
}

const genAI = new GoogleGenerativeAI(process.env.GEMINI_API_KEY || '');
const model = genAI.getGenerativeModel({ model: "gemini-pro" });

export async function generateReactionExplanation(reaction: Reaction): Promise<string> {
  return retryWithExponentialBackoff(async () => {
    try {
      const prompt = sanitizeText(`
        Explain the following chemical reaction in detail:
        Name: ${reaction.name}
        Description: ${reaction.description}
        Reactants: ${JSON.stringify(reaction.reactants)}
        Products: ${JSON.stringify(reaction.products)}
        Conditions: ${JSON.stringify(reaction.conditions)}
        ${reaction.mechanism ? `Mechanism: ${JSON.stringify(reaction.mechanism)}` : ''}

        Please provide:
        1. Detailed step-by-step mechanism
        2. Important conditions and considerations
        3. Common pitfalls to avoid
        4. Real-world applications

        Format your response in markdown for better readability.
      `);

      const result = await model.generateContent(prompt);
      const response = await result.response;
      return response.text();
    } catch (error) {
      console.error('Error in generateReactionExplanation:', error);
      throw new Error(`Failed to generate reaction explanation: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
  });
}

export async function generateMechanismHints(reaction: Reaction, step: number): Promise<string[]> {
  return retryWithExponentialBackoff(async () => {
    try {
      if (!reaction.mechanism?.steps || step >= reaction.mechanism.steps.length) {
        return ["No hint available for this step"];
      }

      const currentStep = reaction.mechanism.steps[step];
      const prompt = sanitizeText(`
        For the reaction "${reaction.name}", provide hints for the following mechanism step:
        ${JSON.stringify(currentStep)}

        Provide 3 helpful hints that will guide students to understand this step.
        Format the response as a JSON array of strings.
      `);

      const result = await model.generateContent(prompt);
      const response = await result.response;

      try {
        const hints = JSON.parse(response.text());
        return Array.isArray(hints) ? hints : ["Could not parse hints properly"];
      } catch (error) {
        console.error('Error parsing hints:', error);
        return ["Could not generate hints for this step"];
      }
    } catch (error) {
      console.error('Error in generateMechanismHints:', error);
      throw new Error(`Failed to generate hints: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
  });
}

function sanitizeText(text: string): string {
  return text
    .normalize('NFKD')
    .replace(/[\u0300-\u036f]/g, '')
    .replace(/[^\x00-\x7F]/g, '')
    .replace(/\s+/g, ' ')
    .trim();
}

const MAX_RETRIES = 3;
const RETRY_DELAY = 1000;

async function retryWithExponentialBackoff<T>(
  operation: () => Promise<T>,
  retries: number = MAX_RETRIES
): Promise<T> {
  try {
    return await operation();
  } catch (error) {
    if (retries === 0) throw error;
    await new Promise(resolve => setTimeout(resolve, RETRY_DELAY * (MAX_RETRIES - retries + 1)));
    return retryWithExponentialBackoff(operation, retries - 1);
  }
}