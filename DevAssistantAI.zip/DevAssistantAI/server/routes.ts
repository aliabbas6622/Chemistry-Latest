import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { generateReactionExplanation } from "./ai";
import { 
  insertMoleculeSchema, 
  insertReactionSchema, 
  insertExplanationSchema,
  insertFunctionalGroupSchema 
} from "@shared/schema";

export async function registerRoutes(app: Express): Promise<Server> {
  // Functional Groups
  app.get("/api/functional-groups", async (_req, res) => {
    const groups = await storage.getFunctionalGroups();
    res.json(groups);
  });

  app.get("/api/functional-groups/:id", async (req, res) => {
    const group = await storage.getFunctionalGroup(parseInt(req.params.id));
    if (!group) {
      res.status(404).json({ message: "Functional group not found" });
      return;
    }
    res.json(group);
  });

  app.post("/api/functional-groups", async (req, res) => {
    const parsed = insertFunctionalGroupSchema.safeParse(req.body);
    if (!parsed.success) {
      res.status(400).json({ message: "Invalid functional group data", errors: parsed.error.errors });
      return;
    }
    const group = await storage.createFunctionalGroup(parsed.data);
    res.json(group);
  });

  // Molecules
  app.get("/api/molecules", async (_req, res) => {
    const molecules = await storage.getMolecules();
    res.json(molecules);
  });

  app.get("/api/molecules/:id", async (req, res) => {
    const molecule = await storage.getMolecule(parseInt(req.params.id));
    if (!molecule) {
      res.status(404).json({ message: "Molecule not found" });
      return;
    }
    res.json(molecule);
  });

  app.post("/api/molecules", async (req, res) => {
    const parsed = insertMoleculeSchema.safeParse(req.body);
    if (!parsed.success) {
      res.status(400).json({ message: "Invalid molecule data", errors: parsed.error.errors });
      return;
    }
    const molecule = await storage.createMolecule(parsed.data);
    res.json(molecule);
  });

  // Reactions
  app.get("/api/reactions", async (_req, res) => {
    const reactions = await storage.getReactions();
    res.json(reactions);
  });

  app.get("/api/reactions/:id", async (req, res) => {
    const reaction = await storage.getReaction(parseInt(req.params.id));
    if (!reaction) {
      res.status(404).json({ message: "Reaction not found" });
      return;
    }
    res.json(reaction);
  });

  app.post("/api/reactions", async (req, res) => {
    const parsed = insertReactionSchema.safeParse(req.body);
    if (!parsed.success) {
      res.status(400).json({ message: "Invalid reaction data", errors: parsed.error.errors });
      return;
    }
    const reaction = await storage.createReaction(parsed.data);
    res.json(reaction);
  });

  // Explanations
  app.get("/api/reactions/:id/explanations", async (req, res) => {
    const explanations = await storage.getExplanationsForReaction(parseInt(req.params.id));
    res.json(explanations);
  });

  app.post("/api/reactions/:id/explanations", async (req, res) => {
    const parsed = insertExplanationSchema.safeParse(req.body);
    if (!parsed.success) {
      res.status(400).json({ message: "Invalid explanation data", errors: parsed.error.errors });
      return;
    }
    const explanation = await storage.createExplanation({
      ...parsed.data,
      reactionId: parseInt(req.params.id)
    });
    res.json(explanation);
  });

  // AI-generated explanations
  app.get("/api/reactions/:id/ai-explanation", async (req, res) => {
    try {
      const reaction = await storage.getReaction(parseInt(req.params.id));
      if (!reaction) {
        res.status(404).json({ message: "Reaction not found" });
        return;
      }

      // Generate AI explanation for the reaction
      const content = await generateReactionExplanation(reaction);

      // Store the AI-generated explanation
      const newExplanation = await storage.createExplanation({
        reactionId: reaction.id,
        content,
        type: "mechanism",
        aiGenerated: true
      });

      res.json(newExplanation);
    } catch (error) {
      console.error("Error generating AI explanation:", error);
      res.status(500).json({ message: "Failed to generate AI explanation" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}