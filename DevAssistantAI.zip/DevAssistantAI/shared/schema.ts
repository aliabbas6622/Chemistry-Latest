import { pgTable, text, serial, integer, jsonb, real, boolean, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const functionalGroups = pgTable("functional_groups", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  description: text("description"),
  structure: jsonb("structure"), // Basic molecular structure
});

export const reactions = pgTable("reactions", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  functionalGroupId: integer("functional_group_id").notNull(),
  type: text("type").notNull(), // 'reaction' or 'preparation'
  description: text("description").notNull(),
  equation: text("equation").notNull(),
  mechanism: jsonb("mechanism"), // Step-by-step mechanism data
  conditions: jsonb("conditions").notNull(), // Temperature, pressure, catalyst
  reactants: jsonb("reactants").notNull(), // Array of molecule IDs and quantities
  products: jsonb("products").notNull(), // Array of molecule IDs and quantities
  difficulty: integer("difficulty").notNull(), // 1-5 scale
  videoUrl: text("video_url"), // Optional video explanation URL
});

export const molecules = pgTable("molecules", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  formula: text("formula").notNull(),
  structure: jsonb("structure").notNull(), // 3D coordinates and bonds
  molecularWeight: real("molecular_weight"),
  type: text("type").notNull(), // organic, inorganic, etc.
});

export const explanations = pgTable("explanations", {
  id: serial("id").primaryKey(),
  reactionId: integer("reaction_id").notNull(),
  content: text("content").notNull(),
  type: text("type").notNull(), // mechanism, theory, application
  aiGenerated: boolean("ai_generated").notNull().default(false),
});

// Insert schemas
export const insertFunctionalGroupSchema = createInsertSchema(functionalGroups);
export const insertReactionSchema = createInsertSchema(reactions);
export const insertMoleculeSchema = createInsertSchema(molecules);
export const insertExplanationSchema = createInsertSchema(explanations);

// Types
export type FunctionalGroup = typeof functionalGroups.$inferSelect;
export type InsertFunctionalGroup = z.infer<typeof insertFunctionalGroupSchema>;
export type Reaction = typeof reactions.$inferSelect;
export type InsertReaction = z.infer<typeof insertReactionSchema>;
export type Molecule = typeof molecules.$inferSelect;
export type InsertMolecule = z.infer<typeof insertMoleculeSchema>;
export type Explanation = typeof explanations.$inferSelect;
export type InsertExplanation = z.infer<typeof insertExplanationSchema>;

// Visualization types
export type VisualizationMode = "ball-stick" | "space-filling" | "wireframe";

// Reaction type enum
export const ReactionType = {
  REACTION: 'reaction',
  PREPARATION: 'preparation',
} as const;