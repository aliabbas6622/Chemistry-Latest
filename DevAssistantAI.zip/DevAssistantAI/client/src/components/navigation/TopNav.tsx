import { Link } from "wouter";
import {
  NavigationMenu,
  NavigationMenuContent,
  NavigationMenuItem,
  NavigationMenuLink,
  NavigationMenuList,
  NavigationMenuTrigger,
} from "@/components/ui/navigation-menu";
import { FUNCTIONAL_GROUPS } from "@/lib/constants";

export default function TopNav() {
  return (
    <nav className="border-b">
      <div className="container flex h-16 items-center">
        <Link href="/">
          <span className="mr-8 text-xl font-bold bg-gradient-to-r from-primary to-blue-600 bg-clip-text text-transparent">
            Chemistry Explorer
          </span>
        </Link>

        <NavigationMenu>
          <NavigationMenuList>
            <NavigationMenuItem>
              <NavigationMenuTrigger>Functional Groups</NavigationMenuTrigger>
              <NavigationMenuContent>
                <div className="grid gap-3 p-4 w-[400px]">
                  {FUNCTIONAL_GROUPS.map(group => (
                    <Link 
                      key={group.id} 
                      href={`/reactions?group=${group.id}`}
                    >
                      <a className="block select-none space-y-1 rounded-md p-3 leading-none no-underline outline-none transition-colors hover:bg-accent hover:text-accent-foreground focus:bg-accent focus:text-accent-foreground">
                        <div className="text-sm font-medium leading-none">{group.name}</div>
                        <p className="line-clamp-2 text-sm leading-snug text-muted-foreground">
                          {group.reactions.length} reactions
                        </p>
                      </a>
                    </Link>
                  ))}
                </div>
              </NavigationMenuContent>
            </NavigationMenuItem>
          </NavigationMenuList>
        </NavigationMenu>
      </div>
    </nav>
  );
}