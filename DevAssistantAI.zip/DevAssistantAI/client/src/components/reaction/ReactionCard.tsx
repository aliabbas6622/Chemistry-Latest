import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Card, CardHeader, CardTitle, CardDescription, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ChevronRight, Book } from "lucide-react";
import type { Reaction } from "@shared/schema";
import MoleculeViewer from "../molecule-viewer/MoleculeViewer";
import Controls from "../molecule-viewer/Controls";
import AIExplanation from "../ai/AIExplanation";

interface Props {
  reaction: Reaction;
}

export default function ReactionCard({ reaction }: Props) {
  const [step, setStep] = useState(0);
  const [showExplanation, setShowExplanation] = useState(false);
  const [mode, setMode] = useState<"ball-stick" | "space-filling" | "wireframe">("ball-stick");

  // Safely get the number of steps from the mechanism
  const maxSteps = reaction.mechanism?.steps?.length ?? 0;

  return (
    <motion.div
      whileHover={{ scale: 1.02 }}
      whileTap={{ scale: 0.98 }}
      transition={{ type: "spring", stiffness: 300, damping: 30 }}
    >
      <Card className="w-full max-w-2xl overflow-hidden transform transition-all duration-200 hover:shadow-lg">
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="text-2xl font-bold">{reaction.name}</CardTitle>
            <Badge variant={getDifficultyVariant(reaction.difficulty)}>
              Level {reaction.difficulty}
            </Badge>
          </div>
          <CardDescription>{reaction.description}</CardDescription>
        </CardHeader>

        <CardContent className="space-y-4">
          <div className="relative h-[300px] rounded-lg overflow-hidden bg-gray-50">
            <AnimatePresence mode="wait">
              {reaction.mechanism?.steps?.[step] && (
                <motion.div
                  key={step}
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: -20 }}
                  transition={{ duration: 0.3 }}
                  className="absolute inset-0"
                >
                  <MoleculeViewer
                    molecule={reaction.mechanism.steps[step].structure}
                    mode={mode}
                    className="w-full h-full"
                  />
                </motion.div>
              )}
            </AnimatePresence>
          </div>

          <Controls mode={mode} onModeChange={setMode} />

          <div className="flex items-center justify-between gap-4">
            <Button
              variant="outline"
              onClick={() => setStep(s => Math.max(0, s - 1))}
              disabled={step === 0}
              className="transition-all duration-200 hover:translate-x-[-4px]"
            >
              <ChevronRight className="w-4 h-4 mr-2 rotate-180" />
              Previous
            </Button>

            <div className="flex gap-2">
              <Button
                variant="secondary"
                onClick={() => setShowExplanation(show => !show)}
                className="transition-all duration-200"
              >
                <Book className="w-4 h-4 mr-2" />
                {showExplanation ? "Hide" : "Show"} Explanation
              </Button>

              <Button
                onClick={() => setStep(s => Math.min(maxSteps - 1, s + 1))}
                disabled={step === maxSteps - 1}
                className="transition-all duration-200 hover:translate-x-[4px]"
              >
                Next
                <ChevronRight className="w-4 h-4 ml-2" />
              </Button>
            </div>
          </div>

          <AnimatePresence>
            {showExplanation && (
              <motion.div
                initial={{ height: 0, opacity: 0 }}
                animate={{ height: "auto", opacity: 1 }}
                exit={{ height: 0, opacity: 0 }}
                transition={{ duration: 0.3 }}
              >
                <AIExplanation reactionId={reaction.id} step={step} />
              </motion.div>
            )}
          </AnimatePresence>
        </CardContent>
      </Card>
    </motion.div>
  );
}

function getDifficultyVariant(difficulty: number) {
  switch (difficulty) {
    case 1: return "secondary";
    case 2: return "default";
    case 3: return "outline";
    case 4: return "destructive";
    case 5: return "destructive";
    default: return "default";
  }
}