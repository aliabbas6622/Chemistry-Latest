import { useMemo } from "react";
import { motion } from "framer-motion";
import {
  AreaChart,
  Area,
  XAxis,
  YAxis,
  Tooltip,
  ResponsiveContainer
} from "recharts";

interface Props {
  currentStep: number;
  totalSteps: number;
  energy: {
    values: number[];
    minValue: number;
    maxValue: number;
  };
}

export default function ReactionProgress({ currentStep, totalSteps, energy }: Props) {
  const data = useMemo(() => {
    return energy.values.map((value, index) => ({
      step: index,
      energy: value,
      isCurrent: index === currentStep
    }));
  }, [energy.values, currentStep]);

  return (
    <div className="space-y-2">
      <div className="flex justify-between text-sm text-muted-foreground">
        <span>Progress: {Math.round((currentStep / (totalSteps - 1)) * 100)}%</span>
        <span>Step {currentStep + 1} of {totalSteps}</span>
      </div>

      <div className="h-[120px]">
        <ResponsiveContainer width="100%" height="100%">
          <AreaChart data={data}>
            <defs>
              <linearGradient id="energyGradient" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor="hsl(var(--primary))" stopOpacity={0.3} />
                <stop offset="100%" stopColor="hsl(var(--primary))" stopOpacity={0} />
              </linearGradient>
            </defs>
            
            <XAxis
              dataKey="step"
              stroke="hsl(var(--muted-foreground))"
              fontSize={12}
              tickLine={false}
            />
            <YAxis
              stroke="hsl(var(--muted-foreground))"
              fontSize={12}
              tickLine={false}
              domain={[energy.minValue, energy.maxValue]}
            />
            
            <Tooltip
              content={({ active, payload }) => {
                if (!active || !payload?.length) return null;
                
                return (
                  <div className="rounded-lg border bg-background p-2 shadow-sm">
                    <p className="text-sm font-medium">
                      Step {payload[0].payload.step + 1}
                    </p>
                    <p className="text-xs text-muted-foreground">
                      Energy: {payload[0].value.toFixed(2)} kJ/mol
                    </p>
                  </div>
                );
              }}
            />
            
            <Area
              type="monotone"
              dataKey="energy"
              stroke="hsl(var(--primary))"
              fill="url(#energyGradient)"
              strokeWidth={2}
            />
            
            {currentStep !== null && (
              <motion.circle
                cx={data[currentStep].step}
                cy={data[currentStep].energy}
                r={4}
                fill="hsl(var(--primary))"
                initial={{ scale: 0 }}
                animate={{ scale: 1 }}
                transition={{ duration: 0.3 }}
              />
            )}
          </AreaChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
}
