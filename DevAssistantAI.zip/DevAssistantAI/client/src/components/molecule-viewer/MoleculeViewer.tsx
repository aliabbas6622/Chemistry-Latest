import { useEffect, useRef } from "react";
import * as THREE from "three";
import { OrbitControls } from "three/examples/jsm/controls/OrbitControls";
import { type Molecule, type VisualizationMode } from "@shared/schema";

interface Props {
  molecule: Molecule;
  mode: VisualizationMode;
  className?: string;
}

// Default empty structure when no molecule data is available
const defaultStructure = {
  atoms: [],
  bonds: []
};

export default function MoleculeViewer({ molecule, mode, className }: Props) {
  const containerRef = useRef<HTMLDivElement>(null);
  const rendererRef = useRef<THREE.WebGLRenderer | null>(null);
  const sceneRef = useRef<THREE.Scene | null>(null);
  const cameraRef = useRef<THREE.PerspectiveCamera | null>(null);
  const controlsRef = useRef<OrbitControls | null>(null);

  useEffect(() => {
    if (!containerRef.current) return;

    // Setup
    const container = containerRef.current;
    const scene = new THREE.Scene();
    const camera = new THREE.PerspectiveCamera(
      75,
      container.clientWidth / container.clientHeight,
      0.1,
      1000
    );
    const renderer = new THREE.WebGLRenderer({ antialias: true });

    renderer.setSize(container.clientWidth, container.clientHeight);
    container.appendChild(renderer.domElement);

    camera.position.z = 5;

    const controls = new OrbitControls(camera, renderer.domElement);
    controls.enableDamping = true;

    // Store refs
    rendererRef.current = renderer;
    sceneRef.current = scene;
    cameraRef.current = camera;
    controlsRef.current = controls;

    // Render molecule based on mode
    const renderMolecule = () => {
      scene.clear();

      // Use structure from molecule or fallback to default
      const structure = molecule?.structure || defaultStructure;
      const { atoms = [], bonds = [] } = structure;

      switch (mode) {
        case "ball-stick":
          atoms.forEach(atom => {
            const geometry = new THREE.SphereGeometry(0.5);
            const material = new THREE.MeshPhongMaterial({ 
              color: getAtomColor(atom.element) 
            });
            const mesh = new THREE.Mesh(geometry, material);
            mesh.position.set(atom.x, atom.y, atom.z);
            scene.add(mesh);
          });

          bonds.forEach(bond => {
            const geometry = new THREE.CylinderGeometry(0.1, 0.1, bond.length);
            const material = new THREE.MeshPhongMaterial({ color: 0x888888 });
            const mesh = new THREE.Mesh(geometry, material);
            mesh.position.set(bond.x, bond.y, bond.z);
            mesh.rotation.set(bond.rx, bond.ry, bond.rz);
            scene.add(mesh);
          });
          break;

        case "space-filling":
          atoms.forEach(atom => {
            const geometry = new THREE.SphereGeometry(atom.radius);
            const material = new THREE.MeshPhongMaterial({ 
              color: getAtomColor(atom.element) 
            });
            const mesh = new THREE.Mesh(geometry, material);
            mesh.position.set(atom.x, atom.y, atom.z);
            scene.add(mesh);
          });
          break;

        case "wireframe":
          bonds.forEach(bond => {
            const material = new THREE.LineBasicMaterial({ color: 0x888888 });
            const points = [
              new THREE.Vector3(bond.start.x, bond.start.y, bond.start.z),
              new THREE.Vector3(bond.end.x, bond.end.y, bond.end.z)
            ];
            const geometry = new THREE.BufferGeometry().setFromPoints(points);
            const line = new THREE.Line(geometry, material);
            scene.add(line);
          });
          break;
      }

      // Add lighting
      const light = new THREE.DirectionalLight(0xffffff, 1);
      light.position.set(5, 5, 5);
      scene.add(light);
      scene.add(new THREE.AmbientLight(0x404040));
    };

    renderMolecule();

    // Animation loop
    const animate = () => {
      requestAnimationFrame(animate);
      controls.update();
      renderer.render(scene, camera);
    };
    animate();

    // Cleanup
    return () => {
      container.removeChild(renderer.domElement);
      renderer.dispose();
    };
  }, [molecule, mode]);

  // If no molecule is provided, render an empty container
  if (!molecule) {
    return <div ref={containerRef} className={className} />;
  }

  return <div ref={containerRef} className={className} />;
}

function getAtomColor(element: string): number {
  const colors: { [key: string]: number } = {
    H: 0xFFFFFF,
    C: 0x808080,
    N: 0x0000FF,
    O: 0xFF0000,
    F: 0x90EE90,
    Cl: 0x90EE90,
    Br: 0x800000,
    I: 0x800080,
  };
  return colors[element] || 0x808080;
}