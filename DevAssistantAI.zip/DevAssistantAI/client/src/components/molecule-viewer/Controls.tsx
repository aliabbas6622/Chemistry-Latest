import { Button } from "@/components/ui/button";
import { type VisualizationMode } from "@shared/schema";
import { Layers, Maximize2, Grid } from "lucide-react";

interface Props {
  mode: VisualizationMode;
  onModeChange: (mode: VisualizationMode) => void;
}

export default function Controls({ mode, onModeChange }: Props) {
  return (
    <div className="flex gap-2 p-2 bg-card rounded-lg shadow-sm">
      <Button
        variant={mode === "ball-stick" ? "default" : "outline"}
        size="sm"
        onClick={() => onModeChange("ball-stick")}
      >
        <Layers className="w-4 h-4 mr-2" />
        Ball & Stick
      </Button>
      
      <Button
        variant={mode === "space-filling" ? "default" : "outline"}
        size="sm"
        onClick={() => onModeChange("space-filling")}
      >
        <Maximize2 className="w-4 h-4 mr-2" />
        Space Filling
      </Button>
      
      <Button
        variant={mode === "wireframe" ? "default" : "outline"}
        size="sm"
        onClick={() => onModeChange("wireframe")}
      >
        <Grid className="w-4 h-4 mr-2" />
        Wireframe
      </Button>
    </div>
  );
}
