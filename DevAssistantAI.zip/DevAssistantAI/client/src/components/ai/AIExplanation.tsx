import { useQuery } from "@tanstack/react-query";
import { AlertCircle, Lightbulb } from "lucide-react";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Skeleton } from "@/components/ui/skeleton";
import { getReactionExplanation, getStepHints } from "@/lib/ai";

interface Props {
  reactionId: number;
  step: number;
}

export default function AIExplanation({ reactionId, step }: Props) {
  const explanationQuery = useQuery({
    queryKey: ["/api/reactions", reactionId, "explanation"],
    queryFn: () => getReactionExplanation(reactionId)
  });

  const hintsQuery = useQuery({
    queryKey: ["/api/reactions", reactionId, "hints", step],
    queryFn: () => getStepHints(reactionId, step)
  });

  if (explanationQuery.isLoading || hintsQuery.isLoading) {
    return (
      <div className="space-y-4 mt-4">
        <Skeleton className="h-20 w-full" />
        <Skeleton className="h-16 w-full" />
      </div>
    );
  }

  if (explanationQuery.isError || hintsQuery.isError) {
    return (
      <Alert variant="destructive" className="mt-4">
        <AlertCircle className="h-4 w-4" />
        <AlertDescription>
          Failed to load AI explanation. Please try again later.
        </AlertDescription>
      </Alert>
    );
  }

  const { mechanism, theory } = explanationQuery.data;
  const hints = hintsQuery.data;

  return (
    <div className="space-y-4 mt-4">
      <div className="space-y-2">
        <h3 className="font-semibold">Mechanism</h3>
        <p className="text-sm text-muted-foreground">{mechanism}</p>
      </div>

      <div className="space-y-2">
        <h3 className="font-semibold">Theory</h3>
        <p className="text-sm text-muted-foreground">{theory}</p>
      </div>

      {hints.length > 0 && (
        <div className="space-y-2">
          <h3 className="font-semibold flex items-center gap-2">
            <Lightbulb className="w-4 h-4" />
            Helpful Hints
          </h3>
          <ul className="space-y-1">
            {hints.map((hint, index) => (
              <li key={index} className="text-sm text-muted-foreground">
                • {hint}
              </li>
            ))}
          </ul>
        </div>
      )}
    </div>
  );
}
