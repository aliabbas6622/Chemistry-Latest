import { useQuery } from "@tanstack/react-query";
import { AlertCircle, Search } from "lucide-react";
import { motion } from "framer-motion";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Skeleton } from "@/components/ui/skeleton";
import ReactionCard from "@/components/reaction/ReactionCard";
import type { Reaction } from "@shared/schema";

export default function Home() {
  const { data: reactions, isLoading, error } = useQuery<Reaction[]>({
    queryKey: ["/api/reactions"],
  });

  return (
    <div className="min-h-screen bg-background">
      <header className="border-b">
        <div className="container py-6">
          <div className="flex items-center justify-between">
            <h1 className="text-4xl font-bold bg-gradient-to-r from-primary to-blue-600 bg-clip-text text-transparent">
              Chemistry Explorer
            </h1>
            <div className="relative w-64">
              <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Search reactions..."
                className="pl-8"
              />
            </div>
          </div>
          <p className="mt-2 text-muted-foreground max-w-2xl">
            Interactive 3D visualization and AI-powered explanations for chemical reactions. 
            Learn mechanisms, theories, and master chemistry concepts step by step.
          </p>
        </div>
      </header>

      <main className="container py-8">
        {isLoading ? (
          <div className="grid gap-6 sm:grid-cols-1 lg:grid-cols-2">
            {[...Array(4)].map((_, i) => (
              <Card key={i}>
                <CardContent className="p-6">
                  <Skeleton className="h-[400px] w-full" />
                </CardContent>
              </Card>
            ))}
          </div>
        ) : error ? (
          <Alert variant="destructive" className="max-w-lg mx-auto">
            <AlertCircle className="h-4 w-4" />
            <AlertDescription>
              Failed to load reactions. Please try again later.
            </AlertDescription>
          </Alert>
        ) : (
          <motion.div 
            className="grid gap-6 sm:grid-cols-1 lg:grid-cols-2"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
          >
            {reactions?.map((reaction, index) => (
              <motion.div
                key={reaction.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.3, delay: index * 0.1 }}
              >
                <ReactionCard reaction={reaction} />
              </motion.div>
            ))}
          </motion.div>
        )}
      </main>

      <footer className="border-t py-6">
        <div className="container text-center text-sm text-muted-foreground">
          Interactive Chemistry Education Platform - Learn through 3D visualization and AI assistance
        </div>
      </footer>
    </div>
  );
}
