import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { useLocation } from "wouter";
import { motion, AnimatePresence } from "framer-motion";
import { Search, Filter, ChevronDown } from "lucide-react";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import ReactionCard from "@/components/reaction/ReactionCard";
import { FUNCTIONAL_GROUPS, type ReactionFilters, type Difficulty, ANIMATION_CONFIG } from "@/lib/constants";

export default function ReactionsPage() {
  const [location] = useLocation();
  const [filters, setFilters] = useState<ReactionFilters>({
    search: "",
    group: null,
    difficulty: null
  });

  // Parse group from URL on mount
  useEffect(() => {
    const params = new URLSearchParams(location.split("?")[1]);
    const groupParam = params.get("group");
    if (groupParam && FUNCTIONAL_GROUPS.some(g => g.id === groupParam)) {
      setFilters(f => ({ ...f, group: groupParam }));
    }
  }, [location]);

  const { data: reactions, isLoading } = useQuery({
    queryKey: ["/api/reactions"],
  });

  const filteredReactions = reactions?.filter(reaction => {
    if (filters.search && !reaction.name.toLowerCase().includes(filters.search.toLowerCase())) {
      return false;
    }
    if (filters.group && !FUNCTIONAL_GROUPS.find(g => g.id === filters.group)?.reactions.includes(reaction.name)) {
      return false;
    }
    if (filters.difficulty && reaction.difficulty !== filters.difficulty) {
      return false;
    }
    return true;
  });

  return (
    <div className="min-h-screen bg-background">
      <div className="container py-8">
        <motion.h1 
          className="text-4xl font-bold bg-gradient-to-r from-primary to-blue-600 bg-clip-text text-transparent mb-8"
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
        >
          Organic Chemistry Reactions
        </motion.h1>

        <motion.div 
          className="flex flex-col gap-4 md:flex-row md:items-center mb-8"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.5, delay: 0.2 }}
        >
          <div className="relative flex-1">
            <Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Search reactions..."
              className="pl-10"
              value={filters.search}
              onChange={(e) => setFilters(f => ({ ...f, search: e.target.value }))}
            />
          </div>

          <div className="flex gap-4">
            <Select
              value={filters.group || "all"}
              onValueChange={(value) => setFilters(f => ({ ...f, group: value === "all" ? null : value }))}
            >
              <SelectTrigger className="w-[200px]">
                <SelectValue placeholder="Select Group" />
                <ChevronDown className="h-4 w-4 opacity-50" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Groups</SelectItem>
                {FUNCTIONAL_GROUPS.map(group => (
                  <SelectItem key={group.id} value={group.id}>
                    {group.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>

            <Select
              value={filters.difficulty?.toString() || "all"}
              onValueChange={(value) => 
                setFilters(f => ({ ...f, difficulty: value === "all" ? null : parseInt(value) as Difficulty }))
              }
            >
              <SelectTrigger className="w-[200px]">
                <SelectValue placeholder="Difficulty" />
                <ChevronDown className="h-4 w-4 opacity-50" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Any Difficulty</SelectItem>
                {[1, 2, 3, 4, 5].map(level => (
                  <SelectItem key={level} value={level.toString()}>
                    Level {level}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </motion.div>

        <div className="overflow-y-auto max-h-[calc(100vh-300px)]">
          <AnimatePresence mode="popLayout">
            <motion.div 
              className="grid gap-6 sm:grid-cols-1 lg:grid-cols-2"
              layout
            >
              {isLoading ? (
                [...Array(4)].map((_, i) => (
                  <motion.div
                    key={`skeleton-${i}`}
                    {...ANIMATION_CONFIG}
                    transition={{ ...ANIMATION_CONFIG.transition, delay: i * 0.1 }}
                  >
                    <Card className="h-[400px] animate-pulse" />
                  </motion.div>
                ))
              ) : filteredReactions?.length === 0 ? (
                <motion.div
                  className="col-span-full text-center py-12"
                  {...ANIMATION_CONFIG}
                >
                  <p className="text-muted-foreground">
                    No reactions found matching your criteria.
                  </p>
                </motion.div>
              ) : (
                filteredReactions?.map((reaction, index) => (
                  <motion.div
                    key={reaction.id}
                    {...ANIMATION_CONFIG}
                    transition={{ ...ANIMATION_CONFIG.transition, delay: index * 0.05 }}
                  >
                    <ReactionCard reaction={reaction} />
                  </motion.div>
                ))
              )}
            </motion.div>
          </AnimatePresence>
        </div>
      </div>
    </div>
  );
}