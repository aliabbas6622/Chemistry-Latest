export const FUNCTIONAL_GROUPS = [
  {
    id: "alkenes",
    name: "Alkenes",
    reactions: ["Dehydration of Alcohol", "Dehydrohalogenation of Alkyl Halide", "Hydrogenation of Alkene", "Halogenation of Alkene", "Hydrohalogenation of Alkene", "Hydration of Alkene", "Halohydration of Alkene", "Epoxidation of Alkene", "Ozonolysis of Alkene", "Polymerization of Alkene"]
  },
  {
    id: "alkynes",
    name: "Alkynes",
    reactions: ["Dehydrohalogenation of Vicinal Dihalide", "Dehalogenation of Tetrahalide", "Hydrogenation of Alkyne", "Hydrohalogenation of Alkyne", "Hydration of Alkyne", "Bromination of Alkyne", "Ozonolysis of Alkyne"]
  },
  {
    id: "benzene",
    name: "Benzene",
    reactions: ["Addition of Benzene H₂ (Hydrogenation)", "Addition of Halogen to Benzene", "Nitration of Benzene", "Sulphonation of Benzene", "Halogenation of Benzene", "Friedel-Crafts Alkylation", "Friedel-Crafts Acylation"]
  },
  {
    id: "alcohols",
    name: "Alcohols",
    reactions: ["Dehydration of Alcohol", "Reaction of Alcohol with HX", "Reaction of Alcohol with SOCl₂", "Reaction of Alcohol with PX₃", "Acid-Catalyzed Dehydration of Alcohols", "Oxidation of Alcohols"]
  },
  {
    id: "phenols",
    name: "Phenols",
    reactions: ["Nitration of Phenol", "Sulphonation of Phenol", "Halogenation of Phenol", "Reaction of Phenol with Sodium Metal", "Oxidation of Phenol"]
  },
  {
    id: "grignard",
    name: "Grignard Reactions",
    reactions: ["Grignard Reagent with Aldehyde", "Grignard Reagent with Ketone", "Grignard Reagent with Formaldehyde", "Grignard Reagent with Ethanal", "Grignard Reagent with Acetone", "Grignard Reagent with Esters"]
  }
];

export type Difficulty = 1 | 2 | 3 | 4 | 5;

export interface ReactionFilters {
  search: string;
  group: string | null;
  difficulty: Difficulty | null;
}

export const ANIMATION_CONFIG = {
  initial: { opacity: 0, y: 20 },
  animate: { opacity: 1, y: 0 },
  exit: { opacity: 0, scale: 0.95 },
  transition: { duration: 0.2 }
};