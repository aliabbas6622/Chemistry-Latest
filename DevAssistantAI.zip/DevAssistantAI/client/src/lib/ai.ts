import { apiRequest } from "./queryClient";
import type { Reaction } from "@shared/schema";

export interface AIExplanation {
  mechanism: string;
  theory: string;
  hints: string[];
}

export async function getReactionExplanation(reactionId: number): Promise<AIExplanation> {
  const res = await apiRequest(
    "GET",
    `/api/reactions/${reactionId}/explanation`
  );
  return res.json();
}

export async function getStepHints(reactionId: number, step: number): Promise<string[]> {
  const res = await apiRequest(
    "GET",
    `/api/reactions/${reactionId}/hints/${step}`
  );
  return res.json();
}
